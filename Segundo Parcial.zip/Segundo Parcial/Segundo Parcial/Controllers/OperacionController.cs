﻿using Infraestructure.Models;
using Infraestructure.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Service;
using System.Reflection;

namespace Examen_Parcial2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OperacionController : Controller
    {
        private OperacionService OperacionService;
        private IConfiguration configuration;
        private CuentaRepository repositoryCuenta;

        public OperacionController(IConfiguration configuration, CuentaRepository repositoryCuenta)
        {
            this.configuration = configuration;
            this.OperacionService = new OperacionService(configuration.GetConnectionString("postgresDB"));
            this.repositoryCuenta = repositoryCuenta;
        }

        /*[HttpPut("transferir/{id}")]
        public ActionResult<string> transferir(string numCuentaOrigen, string numCuentaDestino, decimal monto)
        {
            var cuentaOrigen = repositoryCuenta.ObtenerCuentaPorNumero(numCuentaOrigen);
            var cuentaDestino = repositoryCuenta.ObtenerCuentaPorNumero(numCuentaDestino);

            if (cuentaOrigen == null || cuentaDestino == null)
            {
                return NotFound("Una o ambas cuentas no existen.");
            }

            var resultado = this.OperacionService.transferir(cuentaOrigen, cuentaDestino, monto);
            return Ok(resultado);
        }*/
        [HttpPut("depositar/{id}")]
        public ActionResult<string> depositar(CuentaModel modelo, int id, decimal monto)
        {
            var cuenta = new Infraestructure.Models.CuentaModel
            {
                num_cuenta = modelo.num_cuenta,
                saldo = modelo.saldo,
            };

            var resultado = this.OperacionService.depositar(cuenta, id, monto);
            return Ok(resultado);
        }
        [HttpPut("retirar/{id}")]
        public ActionResult<string> retirar(CuentaModel modelo, int id, decimal monto)
        {
            var cuenta = new Infraestructure.Models.CuentaModel
            {
                num_cuenta = modelo.num_cuenta,
                saldo = modelo.saldo,
            };

            var resultado = this.OperacionService.retirar(cuenta, id, monto);
            return Ok(resultado);
        }
        [HttpPut("bloquear/{id}")]
        public ActionResult<string> bloquear(CuentaModel modelo, int id)
        {
            var cuenta = new Infraestructure.Models.CuentaModel
            {
                estado = "Bloqueado"
            };
            var resultado = this.OperacionService.bloquear(cuenta, id);
            return Ok(resultado);
        }
        [HttpGet("Extracto/{id}")]
        public ActionResult<CuentaModel> extracto(int id)
        {
            var resultado = this.OperacionService.extracto(id);
            return Ok(resultado);
        }
    }
}
