﻿using Infraestructure.Models;
using Infraestructure.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Principal;
using System.Threading.Tasks;

namespace Services.Service
{
    public class OperacionService
    {
        private OperacionRepository repositoryOperacion;
        public OperacionService(string connectionString)
        {
            this.repositoryOperacion = new OperacionRepository(connectionString);
        }
        public string transferir(CuentaModel cuentaOrigen, CuentaModel cuentaDestino, decimal monto)
        {
            return repositoryOperacion.transferir(cuentaOrigen, cuentaDestino, monto);
        }
        public string depositar(CuentaModel cuenta, int id, decimal monto)
        {
            return repositoryOperacion.depositar(cuenta, id, monto);
        }
        public string retirar(CuentaModel cuenta, int id, decimal monto)
        {
            return repositoryOperacion.retirar(cuenta, id, monto);
        }
        public string bloquear(CuentaModel cuenta, int id)
        {
            return repositoryOperacion.bloquear(cuenta, id);
        }
        public CuentaModel extracto(int id)
        {
            return repositoryOperacion.extracto(id);
        }
    }
}
