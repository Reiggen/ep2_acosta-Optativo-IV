﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infraestructure.Models
{
    public class CuentaModel
    {
        public int id { get; set; }
        public int id_cuenta { get; set; }
        public string nom_cuenta { get; set; }
        public string num_cuenta { get; set; }
        public int saldo { get; set; }
        public int lim_saldo { get; set; }
        public int lim_transf { get; set; }
        public string estado { get; set; }
    }
}
