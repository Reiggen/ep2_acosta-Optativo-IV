﻿using Dapper;
using Infraestructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infraestructure.Repository
{
    public class OperacionRepository
    {
        private string _connectionString;
        private Npgsql.NpgsqlConnection connection;
        public OperacionRepository(string connectionString)
        {
            this._connectionString = connectionString;
            this.connection = new Npgsql.NpgsqlConnection(this._connectionString);
        }
        public string transferir(CuentaModel cuentaOrigen, CuentaModel cuentaDestino, decimal monto)
        {
            if (monto <= 0)
            {
                return "El monto del depósito no puede ser menor a 1 gs.";
            }
            if (cuentaOrigen.id == cuentaDestino.id)
            {
                return "No se puede transferir a la misma cuenta.";
            }
            // saldo de la cuenta origen
            decimal saldoOrigen = connection.ExecuteScalar<decimal>($"SELECT saldo FROM cuenta WHERE id = {cuentaOrigen.id}");
            if (monto > saldoOrigen)
            {
                return "Monto insuficiente para realizar transferencia.";
            }
            decimal limiteTransferencia = connection.ExecuteScalar<decimal>($"SELECT lim_transf FROM cuenta WHERE id = {cuentaOrigen.id}");
            if (monto > limiteTransferencia)
            {
                return "El monto a transferir excede el permitido.";
            }
            try
            {
                // movimiento o transferencia de saldo entre las cuentas
                decimal saldoDestino = connection.ExecuteScalar<decimal>($"SELECT saldo FROM cuenta WHERE id = {cuentaDestino.id}");
                decimal nuevoSaldoOrigen = saldoOrigen - monto;
                decimal nuevoSaldoDestino = saldoDestino + monto;
                // actualizacion de los nuevos saldos
                connection.Execute($"UPDATE cuenta SET saldo = {nuevoSaldoOrigen} WHERE id = {cuentaOrigen.id}");
                connection.Execute($"UPDATE cuenta SET saldo = {nuevoSaldoDestino} WHERE id = {cuentaDestino.id}");
                return "Transferencia realizada.";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public string depositar(CuentaModel cuenta, int id, decimal monto)
        {
            if (monto <= 0)
            {
                return "El monto del depósito no puede ser menor a 1 gs.";
            }
            try
            {
                connection.Execute($"UPDATE cuenta SET " +
                    $"saldo = saldo + {monto} " +
                    $"WHERE id = {id}", cuenta);
                return "Deposito de dinero exitoso.";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public string retirar(CuentaModel cuenta, int id, decimal monto)
        {
            if (monto <= 0)
            {
                return "El monto del retiro no puede ser menor a 1 gs.";
            }
            decimal saldoActual = connection.ExecuteScalar<decimal>($"SELECT saldo FROM cuenta WHERE id = {id}");
            if (monto > saldoActual)
            {
                return "El monto a retirar es mayor al saldo disponible en la cuenta.";
            }
            try
            {
                decimal nuevoSaldo = saldoActual - monto;
                connection.Execute($"UPDATE cuenta SET " +
                    $"saldo = {nuevoSaldo} " +
                    $"WHERE id = {id}", cuenta);
                return "Dinero retirado con éxito.";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public string bloquear(CuentaModel cuenta, int id)
        {
            try
            {
                connection.Execute($"UPDATE cuenta SET " +
                    $"estado = 'Bloqueado' " +
                    $"WHERE id = {id}", cuenta);
                return "Cuenta bloqueada correctamente.";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public CuentaModel extracto(int id)
        {
            try
            {
                return connection.QueryFirst<CuentaModel>($"SELECT id_cuenta, nom_cuenta, num_cuenta, saldo FROM cuenta WHERE id = {id}");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
