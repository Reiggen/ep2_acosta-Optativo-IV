﻿using System.ComponentModel.DataAnnotations;

namespace Examen_Parcial2.Models
{
    public class PersonaModel
    {
        public int id_persona { get; set; }

        public string nombre { get; set; }

        public string apellido { get; set; }

        public string tdocumento { get; set; }

        public string ndocumento { get; set; }

        public string direccion { get; set; }

        public string telefono { get; set; }

        public string email { get; set; }

        public string nacionalidad { get; set; }
    }
}

