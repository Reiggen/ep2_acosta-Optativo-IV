﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infraestructure.Models
{
    public class PersonaModel
    {
        public int id_persona { get; set; }

        public String nombre { get; set; }

        public String apellido { get; set; }

        public String tdocumento { get; set; }

        public String ndocumento { get; set; }

        public String direccion { get; set; }

        public String telefono { get; set; }

        public String email { get; set; }

        public String nacionalidad { get; set; }

    }
}
